package com.example.parti.wrappers;

public interface Updatable {
    void update();
}
