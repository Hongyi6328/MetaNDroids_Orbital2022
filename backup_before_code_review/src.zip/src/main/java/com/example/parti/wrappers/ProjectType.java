package com.example.parti.wrappers;

public enum ProjectType {
    APP,
    SURVEY,
    EXPERIMENT,
    OTHER
}
